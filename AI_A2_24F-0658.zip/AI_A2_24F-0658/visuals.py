import tkinter as tk
from tkinter import messagebox

from code import (
    HEURISTICS, ALGORITHMS,
    generate_random_grid, run_search, spawn_obstacles,
)

CELL_SIZE = 30
PADDING   = 10

COLOR_BG        = "#1e1e2e"
COLOR_PANEL     = "#2a2a3e"
COLOR_ACCENT    = "#7c3aed"
COLOR_ACCENT2   = "#06b6d4"
COLOR_TEXT      = "#e2e8f0"
COLOR_SUBTEXT   = "#94a3b8"

COLOR_EMPTY     = "#2d2d44"
COLOR_WALL      = "#475569"
COLOR_START     = "#22c55e"
COLOR_GOAL      = "#f59e0b"
COLOR_FRONTIER  = "#facc15"
COLOR_VISITED   = "#3b82f6"
COLOR_PATH      = "#10b981"
COLOR_AGENT     = "#f43f5e"
COLOR_NEW_WALL  = "#dc2626"

GRID_ROWS_DEF   = 20
GRID_COLS_DEF   = 25
DENSITY_DEF     = 30

ANIM_VISITED_MS = 15
ANIM_PATH_MS    = 30
ANIM_AGENT_MS   = 120


class PathfindingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Dynamic Pathfinding Agent")
        self.root.configure(bg=COLOR_BG)
        self.root.resizable(True, True)

        self.rows      = GRID_ROWS_DEF
        self.cols      = GRID_COLS_DEF
        self.grid      = [[0] * self.cols for _ in range(self.rows)]
        self.start     = (0, 0)
        self.goal      = (self.rows - 1, self.cols - 1)

        self.visited      = []
        self.frontier     = set()
        self.path         = []

        self.agent_pos    = None
        self.agent_index  = 0
        self.animating    = False
        self.paused       = False
        self.dynamic_mode = False
        self.flash_cells  = {}

        self.full_path      = []
        self.full_vis       = []
        self.full_frontiers = []
        self.nodes_visited  = 0
        self.path_cost      = 0
        self.exec_time      = 0.0

        self.anim_phase = "idle"
        self.anim_idx   = 0
        self._anim_id   = None

        self.visited_set  = set()
        self.path_set     = set()
        self.frontier_set = set()

        self._build_ui()
        self.reset_grid()

    def _build_ui(self):
        left = tk.Frame(self.root, bg=COLOR_PANEL, width=260, padx=14, pady=14)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        self._section(left, "GRID SETTINGS")
        self._spin(left, "Rows:",                 "rows_var",    5,  40, GRID_ROWS_DEF)
        self._spin(left, "Cols:",                 "cols_var",    5,  60, GRID_COLS_DEF)
        self._spin(left, "Obstacle Density (%):", "density_var", 0,  80, DENSITY_DEF)
        self._btn(left, "Generate Random Map", self.generate_random, COLOR_ACCENT)
        self._btn(left, "Clear Grid",          self.reset_grid,      "#374151")

        self._section(left, "EDIT MODE")
        self.edit_mode = tk.StringVar(value="Wall")
        for mode in ["Wall", "Erase", "Start", "Goal"]:
            tk.Radiobutton(left, text=mode, variable=self.edit_mode, value=mode,
                           bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_ACCENT,
                           activebackground=COLOR_PANEL,
                           font=("Segoe UI", 10)).pack(anchor="w", pady=1)

        self._section(left, "ALGORITHM")
        self.algorithm = tk.StringVar(value="A* Search")
        for alg in ALGORITHMS:
            tk.Radiobutton(left, text=alg, variable=self.algorithm, value=alg,
                           bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_ACCENT,
                           activebackground=COLOR_PANEL,
                           font=("Segoe UI", 10)).pack(anchor="w", pady=1)

        self._section(left, "HEURISTIC")
        self.heuristic = tk.StringVar(value="Manhattan")
        for h in HEURISTICS:
            tk.Radiobutton(left, text=h, variable=self.heuristic, value=h,
                           bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_ACCENT,
                           activebackground=COLOR_PANEL,
                           font=("Segoe UI", 10)).pack(anchor="w", pady=1)

        self._section(left, "DYNAMIC MODE")
        self.dyn_var = tk.BooleanVar(value=False)
        tk.Checkbutton(left, text="Enable Dynamic Obstacles", variable=self.dyn_var,
                       bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_ACCENT,
                       activebackground=COLOR_PANEL, font=("Segoe UI", 10),
                       command=lambda: setattr(self, "dynamic_mode", self.dyn_var.get())
                       ).pack(anchor="w")

        self._section(left, "CONTROLS")
        self._btn(left, "Run Search",     self.run_search,   COLOR_ACCENT)
        self._btn(left, "Pause / Resume", self.toggle_pause, "#0891b2")
        self._btn(left, "Stop",           self.stop_search,  "#b91c1c")

        self._section(left, "METRICS")
        self.lbl_nodes  = self._metric(left, "Nodes Visited",  "0")
        self.lbl_cost   = self._metric(left, "Path Cost",      "0")
        self.lbl_time   = self._metric(left, "Exec Time (ms)", "0.00")
        self.lbl_status = self._metric(left, "Status",         "Idle")

        self._section(left, "LEGEND")
        for color, label in [
            (COLOR_START,    "Start Node"),
            (COLOR_GOAL,     "Goal Node"),
            (COLOR_FRONTIER, "Frontier (Yellow)"),
            (COLOR_VISITED,  "Visited (Blue)"),
            (COLOR_PATH,     "Final Path (Green)"),
            (COLOR_AGENT,    "Agent (Red)"),
            (COLOR_WALL,     "Wall"),
            (COLOR_NEW_WALL, "New Wall (Flash)"),
        ]:
            row = tk.Frame(left, bg=COLOR_PANEL)
            row.pack(fill=tk.X, pady=1)
            tk.Label(row, bg=color, width=3).pack(side=tk.LEFT, padx=(0, 6))
            tk.Label(row, text=label, bg=COLOR_PANEL, fg=COLOR_TEXT,
                     font=("Segoe UI", 9)).pack(side=tk.LEFT)

        right = tk.Frame(self.root, bg=COLOR_BG)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(right, bg=COLOR_BG, highlightthickness=0)
        hbar = tk.Scrollbar(right, orient=tk.HORIZONTAL, command=self.canvas.xview)
        vbar = tk.Scrollbar(right, orient=tk.VERTICAL,   command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=hbar.set, yscrollcommand=vbar.set)
        hbar.pack(side=tk.BOTTOM, fill=tk.X)
        vbar.pack(side=tk.RIGHT,  fill=tk.Y)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas.bind("<Button-1>",   self._on_click)
        self.canvas.bind("<B1-Motion>",  self._on_drag)
        self.canvas.bind("<MouseWheel>", self._on_scroll)

    def _section(self, p, title):
        tk.Label(p, text=title, bg=COLOR_PANEL, fg=COLOR_ACCENT2,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(12, 2))

    def _btn(self, p, text, cmd, color):
        tk.Button(p, text=text, command=cmd, bg=color, fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat", cursor="hand2",
                  activebackground=color, pady=5).pack(fill=tk.X, pady=3)

    def _spin(self, p, label, attr, lo, hi, default):
        f = tk.Frame(p, bg=COLOR_PANEL)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text=label, bg=COLOR_PANEL, fg=COLOR_TEXT,
                 font=("Segoe UI", 9)).pack(side=tk.LEFT)
        var = tk.IntVar(value=default)
        setattr(self, attr, var)
        tk.Spinbox(f, from_=lo, to=hi, textvariable=var, width=5,
                   bg=COLOR_BG, fg=COLOR_TEXT,
                   font=("Segoe UI", 9)).pack(side=tk.RIGHT)

    def _metric(self, p, label, value):
        f = tk.Frame(p, bg=COLOR_PANEL)
        f.pack(fill=tk.X, pady=1)
        tk.Label(f, text=label + ":", bg=COLOR_PANEL, fg=COLOR_SUBTEXT,
                 font=("Segoe UI", 9)).pack(side=tk.LEFT)
        lbl = tk.Label(f, text=value, bg=COLOR_PANEL, fg=COLOR_TEXT,
                       font=("Segoe UI", 9, "bold"))
        lbl.pack(side=tk.RIGHT)
        return lbl

    def reset_grid(self):
        self.stop_search()
        self.rows  = self.rows_var.get()
        self.cols  = self.cols_var.get()
        self.grid  = [[0] * self.cols for _ in range(self.rows)]
        self.start = (0, 0)
        self.goal  = (self.rows - 1, self.cols - 1)
        self._clear_vis()
        self._update_metrics(0, 0, 0.0, "Idle")
        self._draw_grid()

    def generate_random(self):
        self.stop_search()
        self.rows = self.rows_var.get()
        self.cols = self.cols_var.get()
        density   = self.density_var.get() / 100.0
        self.grid = generate_random_grid(self.rows, self.cols, density,
                                         self.start, self.goal)
        self._clear_vis()
        self._update_metrics(0, 0, 0.0, "Ready")
        self._draw_grid()

    def _clear_vis(self):
        self.visited      = []
        self.visited_set  = set()
        self.path         = []
        self.path_set     = set()
        self.frontier     = set()
        self.frontier_set = set()
        self.agent_pos    = None
        self.flash_cells  = {}

    def _cell_color(self, r, c):
        cell = (r, c)
        if cell == self.start:        return COLOR_START
        if cell == self.goal:         return COLOR_GOAL
        if cell == self.agent_pos:    return COLOR_AGENT
        if cell in self.flash_cells:  return COLOR_NEW_WALL
        if self.grid[r][c] == 1:      return COLOR_WALL
        if cell in self.path_set:     return COLOR_PATH
        if cell in self.frontier_set: return COLOR_FRONTIER
        if cell in self.visited_set:  return COLOR_VISITED
        return COLOR_EMPTY

    def _draw_grid(self):
        self.canvas.delete("all")
        W = self.cols * CELL_SIZE + 2 * PADDING
        H = self.rows * CELL_SIZE + 2 * PADDING
        self.canvas.configure(scrollregion=(0, 0, W, H))
        for r in range(self.rows):
            for c in range(self.cols):
                self._draw_cell(r, c)

    def _draw_cell(self, r, c):
        x1 = PADDING + c * CELL_SIZE
        y1 = PADDING + r * CELL_SIZE
        x2 = x1 + CELL_SIZE - 1
        y2 = y1 + CELL_SIZE - 1
        color = self._cell_color(r, c)
        self.canvas.create_rectangle(x1, y1, x2, y2,
                                     fill=color, outline="#1a1a2e", width=1)
        cx = (x1 + x2) // 2
        cy = (y1 + y2) // 2
        cell = (r, c)
        if cell == self.start:
            self.canvas.create_text(cx, cy, text="S", fill="white",
                                    font=("Segoe UI", 10, "bold"))
        elif cell == self.goal:
            self.canvas.create_text(cx, cy, text="G", fill="white",
                                    font=("Segoe UI", 10, "bold"))
        elif cell == self.agent_pos:
            self.canvas.create_text(cx, cy, text="A", fill="white",
                                    font=("Segoe UI", 10, "bold"))

    def _canvas_to_cell(self, event):
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        return int((y - PADDING) // CELL_SIZE), int((x - PADDING) // CELL_SIZE)

    def _apply_edit(self, r, c):
        if not (0 <= r < self.rows and 0 <= c < self.cols):
            return
        mode = self.edit_mode.get()
        if mode == "Wall":
            if (r, c) not in (self.start, self.goal):
                self.grid[r][c] = 1
        elif mode == "Erase":
            self.grid[r][c] = 0
        elif mode == "Start":
            self.grid[r][c] = 0
            self.start = (r, c)
        elif mode == "Goal":
            self.grid[r][c] = 0
            self.goal = (r, c)
        self._draw_grid()

    def _on_click(self, event):
        if self.animating:
            return
        r, c = self._canvas_to_cell(event)
        self._apply_edit(r, c)

    def _on_drag(self, event):
        if self.animating:
            return
        r, c = self._canvas_to_cell(event)
        if self.edit_mode.get() in ("Wall", "Erase"):
            self._apply_edit(r, c)

    def _on_scroll(self, event):
        self.canvas.yview_scroll(-1 * (event.delta // 120), "units")

    def run_search(self):
        if self.animating:
            return
        self.stop_search()

        path, vis, frontiers, nv, cost, ms = run_search(
            self.grid, self.start, self.goal,
            self.rows, self.cols,
            self.algorithm.get(), self.heuristic.get()
        )

        if path is None:
            self._update_metrics(nv, 0, ms, "No Path Found")
            messagebox.showwarning("No Path", "No path exists to the goal!")
            return

        self.full_path      = path
        self.full_vis       = vis
        self.full_frontiers = frontiers
        self.nodes_visited  = nv
        self.path_cost      = cost
        self.exec_time      = ms

        self._update_metrics(nv, cost, ms, "Animating")
        self._clear_vis()
        self.agent_pos   = self.start
        self.agent_index = 0
        self.anim_phase  = "visited"
        self.anim_idx    = 0
        self.animating   = True
        self.paused      = False
        self._draw_grid()
        self._animate()

    def _animate(self):
        if not self.animating:
            return
        if self.paused:
            self._anim_id = self.root.after(100, self._animate)
            return

        if self.anim_phase == "visited":
            if self.anim_idx < len(self.full_vis):
                node = self.full_vis[self.anim_idx]
                self.visited.append(node)
                self.visited_set.add(node)
                if self.anim_idx < len(self.full_frontiers):
                    self.frontier_set = set(self.full_frontiers[self.anim_idx])
                else:
                    self.frontier_set = set()
                self.anim_idx += 1
                self._draw_cell(*node)
                for fc in self.frontier_set:
                    self._draw_cell(*fc)
                self._anim_id = self.root.after(ANIM_VISITED_MS, self._animate)
            else:
                self.frontier_set = set()
                self.anim_phase   = "path"
                self.anim_idx     = 0
                self._animate()

        elif self.anim_phase == "path":
            if self.anim_idx < len(self.full_path):
                node = self.full_path[self.anim_idx]
                self.path.append(node)
                self.path_set.add(node)
                self.anim_idx += 1
                self._draw_cell(*node)
                self._anim_id = self.root.after(ANIM_PATH_MS, self._animate)
            else:
                self.anim_phase  = "agent"
                self.agent_index = 0
                self._animate()

        elif self.anim_phase == "agent":
            if self.agent_index >= len(self.full_path):
                self.animating = False
                self._update_metrics(self.nodes_visited, self.path_cost,
                                     self.exec_time, "Goal Reached")
                self.lbl_status.config(fg="#22c55e")
                return

            prev           = self.agent_pos
            self.agent_pos = self.full_path[self.agent_index]
            self.agent_index += 1

            if self.dynamic_mode:
                protected = {self.start, self.goal, self.agent_pos}
                new_walls = spawn_obstacles(self.grid, self.rows, self.cols, protected)
                for cell in new_walls:
                    self.flash_cells[cell] = 4

            expired = [k for k, v in self.flash_cells.items() if v <= 0]
            for k in expired:
                del self.flash_cells[k]
            for k in list(self.flash_cells):
                if k in self.flash_cells:
                    self.flash_cells[k] -= 1

            remaining = self.full_path[self.agent_index:]
            if any(self.grid[r][c] == 1 for r, c in remaining):
                self._replan()
                return

            if prev:
                self._draw_cell(*prev)
            self._draw_cell(*self.agent_pos)
            self._anim_id = self.root.after(ANIM_AGENT_MS, self._animate)

    def _replan(self):
        path, vis, frontiers, nv, cost, ms = run_search(
            self.grid, self.agent_pos, self.goal,
            self.rows, self.cols,
            self.algorithm.get(), self.heuristic.get()
        )
        self.exec_time     += ms
        self.nodes_visited += nv

        if path is None:
            self.animating = False
            self._update_metrics(self.nodes_visited, self.path_cost,
                                 self.exec_time, "Path Blocked")
            self.lbl_status.config(fg="#f43f5e")
            messagebox.showwarning("Blocked", "Agent is trapped. No valid path exists.")
            return

        self.full_path      = path
        self.full_vis       = vis
        self.full_frontiers = frontiers
        self.path_cost     += cost
        self.path           = []
        self.visited        = []
        self.path_set       = set()
        self.visited_set    = set()
        self.frontier_set   = set()
        self.anim_phase     = "path"
        self.anim_idx       = 0
        self._update_metrics(self.nodes_visited, self.path_cost,
                             self.exec_time, "Re-planning")
        self._draw_grid()
        self._animate()

    def toggle_pause(self):
        if not self.animating:
            return
        self.paused = not self.paused
        self.lbl_status.config(text="Paused" if self.paused else "Animating")

    def stop_search(self):
        self.animating = False
        self.paused    = False
        if self._anim_id:
            self.root.after_cancel(self._anim_id)
            self._anim_id = None
        self._clear_vis()
        self._update_metrics(0, 0, 0.0, "Idle")
        if self.grid:
            self._draw_grid()

    def _update_metrics(self, nodes, cost, ms, status):
        self.lbl_nodes.config(text=str(nodes))
        self.lbl_cost.config(text=str(cost))
        self.lbl_time.config(text=f"{ms:.2f}")
        self.lbl_status.config(text=status, fg=COLOR_TEXT)


if __name__ == "__main__":
    root = tk.Tk()
    app  = PathfindingApp(root)
    root.mainloop()