"""
code.py  —  Search Algorithms & Grid Logic
==========================================
Contains: A*, GBFS, heuristics, neighbour helpers, dynamic re-planning.
Imported by visuals.py — no GUI code here.
"""

import heapq
import random
import math
import time


# ─────────────────────────────────────────────
#  HEURISTICS
# ─────────────────────────────────────────────
def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def euclidean(a, b):
    return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)

def chebyshev(a, b):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))

HEURISTICS = {
    "Manhattan":  manhattan,
    "Euclidean":  euclidean,
    "Chebyshev":  chebyshev,
}

ALGORITHMS = ["A* Search", "Greedy Best-First Search"]


# ─────────────────────────────────────────────
#  GRID HELPERS
# ─────────────────────────────────────────────
def get_neighbors(grid, node, rows, cols):
    """Yield walkable 4-directional neighbours."""
    r, c = node
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nr, nc = r + dr, c + dc
        if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] != 1:
            yield (nr, nc)


def generate_random_grid(rows, cols, density, start, goal):
    """Return a 2-D grid with random walls at the given density."""
    grid = [[0] * cols for _ in range(rows)]
    for r in range(rows):
        for c in range(cols):
            if (r, c) not in (start, goal):
                grid[r][c] = 1 if random.random() < density else 0
    return grid


# ─────────────────────────────────────────────
#  A* SEARCH
# ─────────────────────────────────────────────
def astar(grid, start, goal, rows, cols, heuristic_fn):
    """
    A* Search  →  f(n) = g(n) + h(n)

    Returns:
        path          – list of cells from start to goal (or None)
        visited_order – cells in expansion order
        frontier_sets – list of frontier snapshots (one per expansion)
        nodes_visited – total expanded nodes
        cost          – path length - 1
        exec_ms       – wall-clock time in milliseconds
    """
    h = heuristic_fn
    t0 = time.perf_counter()

    open_heap     = []
    counter       = 0
    heapq.heappush(open_heap, (h(start, goal), counter, 0, start, [start]))

    visited       = {}          # node -> best g seen
    visited_order = []
    frontier_sets = []          # snapshot of open set at each expansion
    in_open       = {start}     # tracks what is currently in the heap (approximate)

    while open_heap:
        f, _, g, node, path = heapq.heappop(open_heap)
        in_open.discard(node)

        if node in visited and visited[node] <= g:
            continue
        visited[node] = g
        visited_order.append(node)
        frontier_sets.append(frozenset(in_open))   # snapshot AFTER popping

        if node == goal:
            elapsed = (time.perf_counter() - t0) * 1000
            return path, visited_order, frontier_sets, len(visited_order), len(path) - 1, elapsed

        for nb in get_neighbors(grid, node, rows, cols):
            ng = g + 1
            if nb not in visited or visited.get(nb, float('inf')) > ng:
                counter += 1
                heapq.heappush(open_heap, (ng + h(nb, goal), counter, ng, nb, path + [nb]))
                in_open.add(nb)

    elapsed = (time.perf_counter() - t0) * 1000
    return None, visited_order, frontier_sets, len(visited_order), 0, elapsed


# ─────────────────────────────────────────────
#  GREEDY BEST-FIRST SEARCH
# ─────────────────────────────────────────────
def gbfs(grid, start, goal, rows, cols, heuristic_fn):
    """
    Greedy Best-First Search  →  f(n) = h(n)

    Returns same tuple as astar().
    """
    h = heuristic_fn
    t0 = time.perf_counter()

    open_heap     = []
    counter       = 0
    heapq.heappush(open_heap, (h(start, goal), counter, start, [start]))

    visited       = set()
    visited_order = []
    frontier_sets = []
    in_open       = {start}

    while open_heap:
        _, _, node, path = heapq.heappop(open_heap)
        in_open.discard(node)

        if node in visited:
            continue
        visited.add(node)
        visited_order.append(node)
        frontier_sets.append(frozenset(in_open))

        if node == goal:
            elapsed = (time.perf_counter() - t0) * 1000
            return path, visited_order, frontier_sets, len(visited_order), len(path) - 1, elapsed

        for nb in get_neighbors(grid, node, rows, cols):
            if nb not in visited:
                counter += 1
                heapq.heappush(open_heap, (h(nb, goal), counter, nb, path + [nb]))
                in_open.add(nb)

    elapsed = (time.perf_counter() - t0) * 1000
    return None, visited_order, frontier_sets, len(visited_order), 0, elapsed


# ─────────────────────────────────────────────
#  UNIFIED DISPATCHER
# ─────────────────────────────────────────────
def run_search(grid, start, goal, rows, cols, algorithm, heuristic_name):
    """
    Run the chosen algorithm with the chosen heuristic.
    Returns (path, visited_order, frontier_sets, nodes_visited, cost, exec_ms).
    """
    h_fn = HEURISTICS.get(heuristic_name, manhattan)
    if algorithm == "A* Search":
        return astar(grid, start, goal, rows, cols, h_fn)
    else:
        return gbfs(grid, start, goal, rows, cols, h_fn)


# ─────────────────────────────────────────────
#  DYNAMIC OBSTACLE SPAWNER
# ─────────────────────────────────────────────
DYNAMIC_PROB = 0.04   # probability per free cell per agent step

def spawn_obstacles(grid, rows, cols, protected):
    """
    Randomly turn free cells into walls with probability DYNAMIC_PROB.
    protected – set of cells that must not become walls (start, goal, agent pos).
    Returns list of newly created wall cells.
    """
    spawned = []
    for r in range(rows):
        for c in range(cols):
            if (r, c) not in protected and grid[r][c] == 0:
                if random.random() < DYNAMIC_PROB:
                    grid[r][c] = 1
                    spawned.append((r, c))
    return spawned
